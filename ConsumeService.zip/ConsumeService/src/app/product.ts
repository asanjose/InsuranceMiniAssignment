export class Product{
    Id: number;
    Name: string;
    Category: string;
    Price: string;

}

