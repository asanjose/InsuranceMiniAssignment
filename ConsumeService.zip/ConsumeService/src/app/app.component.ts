import { Component, OnInit } from '@angular/core';
import {TestService} from './test.service';
import {HttpClient} from '@angular/common/http'
import {RootObject} from './RootObject';
import { ProductService } from './product.service';
import { getDefaultService } from '../../node_modules/@types/selenium-webdriver/edge';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  products: any[];
  result: RootObject[];
  single: RootObject;
  isValid: boolean = false;
  id = 11;
  columns = ['Id','Company_Name', 'Product_Type', 'Email', 'Rate'];


  constructor(private productService: ProductService, private http: HttpClient){
  }
 
  /*This method is handling the display of data through "*ngIf" within the app.component.html file.
  So once the user proceeds with their input and clicks the enter key, it will change the "isValid"
  value to true. If the search is successful and has the value true, it will display the contents
  of a specific object or company in this case.
  */
  changeValue(valid: boolean) {
    this.isValid = valid;
    console.log(valid);
     }

//This method is going to populate the table provided to the associated html file right when the pages load.
  ngOnInit(): void {
    this.productService.getUsers()
        .subscribe(
            result => {
                this.result = result;
                console.log('this.result=' + this.result);
            }, //Bind to view
                        err => {
                    // Log errors if any
                    console.log(err);
                })
}

//This method will change the appearance of the table once its associated button is clicked.
getSortedRate(): void {
    this.productService.SortHighestRate()
    .subscribe(
        result => {
            this.result = result;
            console.log('this.result=' + this.result);
        }, //Bind to view
                    err => {
                // Log errors if any
                console.log(err);
            })

}

//This method will be grabbing the singular object the user is looking for
getOneUser(id:number) {
    this.productService.getUser(id)
    .subscribe(
        single =>{
            this.single = single;
            console.log('Id='+ this.single.Id)
        },
        err =>{
            console.log(err);
        }
    )
}

postNewStaticData(){
    this.productService.postNewRandomObject()
    .subscribe(
        result => {
            this.result = result;
            console.log("New Data =" + this.result)
            console.log(this.id)
        },
        err =>{
            console.log(err);
        }
    )
}

deleteNewStaticData(id:number): void{
    id = this.id;
    this.productService.deleteNewRandomObject(id)
    .subscribe(
        single => {
            this.single = single;
            console.log("New Result =" + this.id)
        },
        err =>{
            console.log(err);
        }
    )
}

}
