import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import 'rxjs/add/operator/toPromise';
import { Headers, Http } from '@angular/http';


 
import { Product } from './product';
 

@Injectable()
export class TestService{

private readonly rootUrl: string = `http://localhost:8290/api/products`;
private readonly difUrl: string = `http://localhost:22738/api/Insurance`;
private headers = new Headers({'Content-Type': 'application/json'});

constructor( private http:HttpClient){
}


/*getAllProducts(): Promise<Product[]>{
    return this.http.get(this.rootUrl)
    .toPromise()
    .then(response => response.json().data as Product[]);
}*/

getProducts(){
    return this.http.get(this.difUrl);
}

/*getAllProducts(){
    return this.http.get(this.rootUrl);
    }
*/
}