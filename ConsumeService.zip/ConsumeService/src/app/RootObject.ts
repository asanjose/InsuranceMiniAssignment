export class RootObject{

    Id: number;
    Company_Name: string;
    Product_Type: string;
    Email: string;
    Rate: number;

}