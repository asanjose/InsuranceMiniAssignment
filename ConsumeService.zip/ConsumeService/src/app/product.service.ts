
import { Injectable }     from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable }     from 'rxjs/Observable';

import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw'; 

import { RootObject } from './RootObject';
import { Options } from '../../node_modules/@types/selenium-webdriver/ie';

@Injectable()
export class ProductService {
    /*
    getUsers() is used to grab all the data from the api to be later used in a *ngFor

    getUser(id:number) is used to find the specific singular data the user desired.
    It is expecting a number and it will match the number with the proper data id

    SortHighestRate() works similar to getUsers() but is instead ordering the highest
    rate to the lowest rate. The purpose is to show extra functionaility or if a consumer
    is on a budget and needs to see what they can "afford".

    */
   //These links provide the URLs for the Angular application to access http request.
    private readonly URL: string = `http://localhost:22738/api/Insurance`;
    private readonly RateURL: string = `http://localhost:22738/api/SortedRate`;
    private readonly PostURL: string = `http://localhost:22738/api/AddRandom`;
    private readonly DeleteURL: string = `http://localhost:22738/api/DeleteRandom`;
    constructor (private http: Http) {}

    //This method is going to grab an array of RootObject or the properties associated with the json file variable names.

    getUsers(): Observable<RootObject[]> {
        return this.http.get(this.URL)
            .map((response:Response) => response.json()) //This map function allows us to connect the values of our Angular model to the API model or expected format from the json file
                .catch((error:any) => Observable.throw(error.json().error || 'Server error'));
    }

    getUser(id:number): Observable<RootObject>{
        return this.http.get(`${this.URL}/${id}`)
        .map((response:Response) => response.json())
        .catch((error:any) => Observable.throw(error.json().error || 'Server error'));

    }

    SortHighestRate(): Observable<RootObject[]> {
        return this.http.get(this.RateURL)
            .map((response:Response) => response.json())
                .catch((error:any) => Observable.throw(error.json().error || 'Server error'));
    }

    postNewRandomObject(): Observable<RootObject[]>{
        return this.http.post(this.PostURL, RootObject)
        .map((response:Response) => response.json())
        .catch((error:any) => Observable.throw(error.json().error || 'Server error'));
    }

    deleteNewRandomObject(Id:number): Observable<RootObject>{
        return this.http.delete(`${this.DeleteURL}/${Id}`)
        .map((response:Response) => response.json())
        .catch((error:any) => Observable.throw(error.error || 'Server error'));
    }
}